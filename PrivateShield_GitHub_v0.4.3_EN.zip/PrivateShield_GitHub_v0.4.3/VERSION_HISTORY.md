# PrivateShield 0.4.3 — YouTube and ad-test-site protection

## Changes

- Includes the 0.4.2 fix that protects core YouTube/video domains.
- Adds `iblockads.net` and `can-you-block-it.com` to the protected-domain list.
- On extension update, protected domains are removed from saved reports and dynamic blocking rules are rebuilt. This automatically removes earlier reports for `iblockads.net`.
- This release does not promise to block every ad; it aims to avoid accidentally blocking ad-testing pages and video playback.

## Upgrade from 0.4.2

1. Open `chrome://extensions`.
2. Turn off the currently installed PrivateShield extension.
3. Extract this ZIP into a new folder.
4. If the extension already points to the replaced folder, select **Reload**. Otherwise, remove the old version, select **Load unpacked**, and choose the new folder containing `manifest.json`.
5. Enable the extension and reload https://iblockads.net/test.

**Note:** Chrome may retain dynamic rules between versions. During installation/update, the migration rebuilds reported-domain rules and excludes protected domains. Test the relevant test page and YouTube after upgrading. This package has not been verified directly on the user's computer.
