# PrivateShield

**Version:** 0.4.3  
**Interface language:** English  
**Platform:** Chrome extension (Manifest V3)

PrivateShield is an experimental personal project that blocks selected advertising/tracking requests using rules and lets users manage domains they report.

> **Status:** Early experimental release. It has not undergone an independent security audit and is not antivirus software. It does not guarantee detection or blocking of all ads, trackers, phishing sites, or malware.

## Current features

- Network-blocking rules in `rules.json`.
- Users can report domains to create blocking rules limited to selected request types.
- A protected-domain list helps reduce accidental blocking of core YouTube/video domains and selected ad-testing websites.
- Partial EasyList import; the extension does **not** support the full EasyList filter syntax.
- CSS hides selected advertising elements on YouTube pages; it does not guarantee that video ads will be blocked.

## Install for testing in Chrome

1. Download the source code or extract the ZIP archive.
2. Open `chrome://extensions` in Chrome.
3. Enable **Developer mode**.
4. Select **Load unpacked**.
5. Choose the folder containing `manifest.json`.

Only install extensions from source code you trust. If you encounter an error or a website is incorrectly blocked, disable the extension or remove the relevant blocking rule.

## Chrome permissions

- `declarativeNetRequest`: applies network-request blocking rules.
- `declarativeNetRequestFeedback`: supports rule-match statistics/inspection to the extent allowed by Chrome.
- `storage`: stores settings and user-reported domains.
- `alarms`: runs scheduled tasks, including filter-list updates.
- `host_permissions` for `https://easylist.to/*`: downloads the EasyList filter list.

Review the permissions and source-code behavior before publicly distributing the extension. This README describes the project as it currently exists; it is not a security certification.

## Known limitations

- No download scanner or antivirus functionality.
- No complete phishing or malware detection system.
- The EasyList importer supports only a limited subset of simple rules.
- Domain-blocking rules can break website functionality if used incorrectly.
- The extension has not been independently tested across a wide range of Chrome configurations.

## Contributing and bug reports

When reporting a bug, include the Chrome version, PrivateShield version, affected website, and reproduction steps. Do not share passwords, cookies, browsing history, or personal data.

See [`CONTRIBUTING.md`](CONTRIBUTING.md) for contribution guidance and [`SECURITY.md`](SECURITY.md) for security-reporting guidance.

## License

See `LICENSE`. Before publishing, the project owner should confirm that they have the right to distribute all source code and bundled components under the selected license.
