# Contributing to PrivateShield

Thanks for your interest in contributing! This project is experimental, so clear bug reports and reproducible tests are especially helpful.

## Reporting a bug

Please include:
- PrivateShield version
- Chrome version and operating system
- The affected website (if safe to share)
- Expected behavior and actual behavior
- Minimal reproduction steps
- Relevant error messages, with personal information removed

Never include passwords, cookies, authentication tokens, browsing history, or other personal data.

## Suggesting a feature

Describe the problem the feature would solve, the expected behavior, and any privacy or compatibility implications.

## Code contributions

- Keep changes focused and explain their purpose.
- Test changes in Chrome before submitting them.
- Document known limitations and possible false positives.
- Do not add permissions or network destinations without explaining why they are necessary.
- Do not claim that a change has been security-audited unless an independent audit actually took place.
