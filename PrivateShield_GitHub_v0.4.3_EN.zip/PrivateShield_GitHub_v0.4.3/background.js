const USER_START = 1000;
const USER_END = 1999;
const LIST_START = 2000;
const LIST_END = 2999;
const MAX_LIST_RULES = 1000;
const FILTER_URL = "https://easylist.to/easylist/easylist.txt";
// Core domains and test sites must not be blocked through the report button or test filter list.
const PROTECTED_HOSTS = [
  "youtube.com",
  "youtube-nocookie.com",
  "googlevideo.com",
  "ytimg.com",
  "youtubei.googleapis.com",
  // Ad-testing sites: do not block the test tools themselves.
  "iblockads.net",
  "can-you-block-it.com"
];

function isProtectedHost(host) {
  return PROTECTED_HOSTS.some(root => host === root || host.endsWith("." + root));
}

// Balanced mode: do not block image, media, sub_frame, or other request types.
const BALANCED_TYPES = ["script", "xmlhttprequest", "ping"];

function normalizeHost(input) {
  try {
    const value = String(input || "").trim();
    if (!value) return null;
    const url = new URL(value.includes("://") ? value : "https://" + value);
    const host = url.hostname.toLowerCase().replace(/\.$/, "");
    if (!host || host === "localhost" || !host.includes(".") ||
        /^[0-9.]+$/.test(host) || host.includes("..")) return null;
    return host;
  } catch {
    return null;
  }
}

function makeRule(id, host) {
  return {
    id,
    priority: 1,
    action: { type: "block" },
    condition: {
      urlFilter: "||" + host + "^",
      resourceTypes: BALANCED_TYPES
    }
  };
}

async function rebuildReportedRules() {
  const saved = await chrome.storage.local.get({ reportedHosts: [] });
  const hosts = [...new Set(saved.reportedHosts.map(normalizeHost).filter(Boolean))]
    .filter(host => !isProtectedHost(host))
    .slice(0, USER_END - USER_START + 1);
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const oldRules = existing.filter(r => r.id >= USER_START && r.id <= USER_END);
  const newRules = hosts.map((host, i) => makeRule(USER_START + i, host));
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: oldRules.map(r => r.id),
    addRules: newRules
  });
  await chrome.storage.local.set({ reportedHosts: hosts });
}

async function rebalanceExistingListRules() {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const listRules = existing.filter(r => r.id >= LIST_START && r.id <= LIST_END);
  if (!listRules.length) return;
  const rebuilt = [];
  for (const rule of listRules) {
    const match = String(rule.condition?.urlFilter || "")
      .match(/^\|\|([a-z0-9.-]+\.[a-z]{2,})\^$/i);
    if (match && !isProtectedHost(match[1].toLowerCase())) {
      rebuilt.push(makeRule(rule.id, match[1].toLowerCase()));
    }
  }
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: listRules.map(r => r.id),
    addRules: rebuilt
  });
  await chrome.storage.local.set({ filterRuleCount: rebuilt.length });
}

async function migrateToBalancedMode() {
  try {
    await rebuildReportedRules();
    await rebalanceExistingListRules();
  } catch (error) {
    console.error("PrivateShield: could not migrate rules to balanced mode:", error);
  }
}

async function addReportedHost(host) {
  const data = await chrome.storage.local.get({ reportedHosts: [] });
  const hosts = [...new Set([...data.reportedHosts, host])];
  if (hosts.length > USER_END - USER_START + 1) {
    throw new Error("The limit of 1,000 reported domains has been reached.");
  }
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const oldRules = existing.filter(r => r.id >= USER_START && r.id <= USER_END);
  const newRules = hosts.map((item, index) => makeRule(USER_START + index, item));
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: oldRules.map(r => r.id),
    addRules: newRules
  });
  await chrome.storage.local.set({ reportedHosts: hosts });
  return hosts.length;
}

async function updateFilterList() {
  const response = await fetch(FILTER_URL, { cache: "no-store" });
  if (!response.ok) throw new Error("The filter-list server returned HTTP error " + response.status + ".");
  const text = await response.text();
  const hosts = new Set();

  // The experimental importer understands simple domain rules only, not the full EasyList syntax.
  for (const line of text.split(/\r?\n/)) {
    const match = line.trim().match(/^\|\|([a-z0-9.-]+\.[a-z]{2,})\^$/i);
    if (match && !match[1].includes("..") && !isProtectedHost(match[1].toLowerCase())) {
      hosts.add(match[1].toLowerCase());
    }
    if (hosts.size >= MAX_LIST_RULES) break;
  }
  if (!hosts.size) throw new Error("No matching simple domain rules were found in the list.");

  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const oldRules = existing.filter(r => r.id >= LIST_START && r.id <= LIST_END);
  const newRules = [...hosts].slice(0, MAX_LIST_RULES)
    .map((host, i) => makeRule(LIST_START + i, host));
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: oldRules.map(r => r.id),
    addRules: newRules
  });
  await chrome.storage.local.set({
    lastFilterUpdate: new Date().toISOString(),
    filterRuleCount: newRules.length
  });
  return newRules.length;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("refresh-filter", { periodInMinutes: 1440 });
  migrateToBalancedMode();
});
chrome.runtime.onStartup.addListener(migrateToBalancedMode);

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name === "refresh-filter") {
    try { await updateFilterList(); }
    catch (error) { console.error("PrivateShield: filter update failed:", error); }
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.type === "REPORT_HOST") {
      const host = normalizeHost(message.host);
      if (!host) throw new Error("Invalid URL or domain.");
      if (isProtectedHost(host)) {
        // Also remove any older accidental report immediately.
        const saved = await chrome.storage.local.get({ reportedHosts: [] });
        const cleaned = saved.reportedHosts
          .map(normalizeHost).filter(Boolean)
          .filter(item => !isProtectedHost(item));
        await chrome.storage.local.set({ reportedHosts: cleaned });
        await rebuildReportedRules();
        throw new Error("Refusing to block a core YouTube/video domain. Any older report rule for this domain has been removed, if present.");
      }
      const count = await addReportedHost(host);
      return { ok: true, host, count };
    }
    if (message?.type === "UPDATE_FILTER") {
      const count = await updateFilterList();
      return { ok: true, count };
    }
    if (message?.type === "STATS") {
      const [matched, dynamic, saved] = await Promise.all([
        chrome.declarativeNetRequest.getMatchedRules(),
        chrome.declarativeNetRequest.getDynamicRules(),
        chrome.storage.local.get({ reportedHosts: [], filterRuleCount: 0, lastFilterUpdate: "" })
      ]);
      return {
        ok: true,
        matched: Array.isArray(matched.rules) ? matched.rules.length : 0,
        dynamic: dynamic.length,
        reported: saved.reportedHosts.length,
        filterCount: saved.filterRuleCount,
        lastUpdate: saved.lastFilterUpdate || "Not updated yet"
      };
    }
    throw new Error("Unsupported request.");
  })().then(sendResponse).catch(error => {
    sendResponse({ ok: false, error: error?.message || "An error occurred." });
  });
  return true;
});
