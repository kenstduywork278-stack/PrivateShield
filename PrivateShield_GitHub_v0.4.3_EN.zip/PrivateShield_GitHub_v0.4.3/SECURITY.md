# Security Policy

PrivateShield is a personal project in an experimental stage. Do not include sensitive data, passwords, cookies, or personally identifying information in public bug reports.

When reporting a security issue, describe the impact, affected version, and minimal steps needed to reproduce it. Do not attach live malware or dangerous files to an issue.

Until a private vulnerability-reporting channel is configured for this repository, avoid publishing exploit details or sensitive information in public issues. The project has not undergone an independent security audit.
