const $ = id => document.getElementById(id);
const statusEl = $("status");
const reportButton = $("report");
const updateButton = $("update");
const refreshButton = $("refresh");

function send(type, extra = {}) {
  return chrome.runtime.sendMessage({ type, ...extra });
}

function readableDate(value) {
  if (!value || value === "Not updated yet") return "Not updated yet";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}

async function refreshStats() {
  const result = await send("STATS");
  if (!result?.ok) throw new Error(result?.error || "Could not read statistics.");
  $("stats").textContent =
    `Rules matched this session: ${result.matched}\n` +
    `Reported domains: ${result.reported}\n` +
    `Active dynamic rules: ${result.dynamic}\n` +
    `Test-list rules: ${result.filterCount}`;
  $("filterInfo").textContent =
    `Last updated: ${readableDate(result.lastUpdate)}\n` +
    `Imported rules: ${result.filterCount}`;
}

reportButton.addEventListener("click", async () => {
  const host = $("host").value.trim();
  $("reportResult").textContent = "";
  if (!host) {
    $("reportResult").textContent = "Enter a domain or URL first.";
    return;
  }
  const confirmed = confirm(
    `You are about to block requests to this domain:\n${host}\n\n` +
    "Blocking the wrong domain may break a website. Do you want to continue?"
  );
  if (!confirmed) return;

  reportButton.disabled = true;
  try {
    const result = await send("REPORT_HOST", { host });
    if (!result?.ok) throw new Error(result?.error || "Could not save the report.");
    $("reportResult").textContent =
      `Added ${result.host} to the block list. Total reported domains: ${result.count}.`;
    await refreshStats();
  } catch (error) {
    $("reportResult").textContent = "Error: " + error.message;
  } finally {
    reportButton.disabled = false;
  }
});

updateButton.addEventListener("click", async () => {
  updateButton.disabled = true;
  $("filterInfo").textContent = "Downloading test filter list...";
  try {
    const result = await send("UPDATE_FILTER");
    if (!result?.ok) throw new Error(result?.error || "Could not update the filter list.");
    $("filterInfo").textContent = `Update complete: imported ${result.count} simple domain rules.`;
    await refreshStats();
  } catch (error) {
    $("filterInfo").textContent = "Update failed: " + error.message;
  } finally {
    updateButton.disabled = false;
  }
});

refreshButton.addEventListener("click", async () => {
  refreshButton.disabled = true;
  try {
    await refreshStats();
    statusEl.textContent = "PrivateShield is running.";
  } catch (error) {
    $("stats").textContent = "Error: " + error.message;
  } finally {
    refreshButton.disabled = false;
  }
});

(async function init() {
  try {
    statusEl.textContent = "PrivateShield loaded. Sample rules are enabled.";
    await refreshStats();
  } catch (error) {
    statusEl.textContent = "Could not read status: " + error.message;
    $("stats").textContent = "Check the extension permissions or Chrome errors.";
  }
})();
