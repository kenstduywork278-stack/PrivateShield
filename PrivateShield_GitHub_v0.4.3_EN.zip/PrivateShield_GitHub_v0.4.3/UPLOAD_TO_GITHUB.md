# How to publish PrivateShield on GitHub (no programming required)

1. Visit https://github.com/ and create an account if you do not already have one.
2. Verify your account email address.
3. Select the **+** menu in the upper-right corner, then choose **New repository**.
4. Set **Repository name** to `PrivateShield`.
5. Choose **Public** if you want everyone to be able to view the source code.
6. Do **not** select **Add a README file** when creating the repository, because this package already contains `README.md` and a duplicate may cause a conflict.
7. Select **Create repository**.
8. In the new repository, choose **Add file > Upload files**.
9. Extract this ZIP on your computer and open the `PrivateShield_GitHub_v0.4.3` folder.
10. Drag the **files inside the folder** (not the ZIP archive itself) into GitHub's upload area. Include the `.js`, `.html`, `.css`, and `.json` files, as well as `README.md`, `LICENSE`, `SECURITY.md`, `.gitignore`, and the English documentation files. If `.gitignore` is hidden, enable hidden-file display or add it separately.
11. Wait for the upload to finish. In the commit-message field, enter: `Add PrivateShield v0.4.3 source`.
12. Select **Commit changes**.
13. Open the repository page and check that `manifest.json`, `background.js`, `popup.js`, `popup.html`, `rules.json`, `youtube-cosmetic.css`, `README.md`, and `LICENSE` are present.

## Safety notes

- Never share your GitHub password, verification codes, or recovery codes with anyone.
- Do not publish access tokens, API keys, cookies, or personal data. This package does not need any of those.
- A **Public** repository makes the source code publicly visible.
- The included license is MIT. Keep it only if you have the right to license the source code and bundled components. If you are unsure about ownership or redistribution rights, resolve that before publishing.
- This is an experimental release, not antivirus software, and it has not undergone an independent security audit.
- Uploading the repository does not publish the extension to the Chrome Web Store. That is a separate process.
